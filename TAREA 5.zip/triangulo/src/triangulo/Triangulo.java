/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package triangulo;

/**
 *
 * @author Keren Serrano
 */


  public class Triangulo extends Forma {

    private final double base;
    private double altura;

    public Triangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

   
    public double calcularArea() {
        return 0.5 * base * altura;
    }

  
    public double calcularPerimetro() {
        // Suponiendo que es un triángulo genérico
        return 3 * base;
    }

   
    public void dibujar() {
        System.out.println("Dibujando Triángulo");
    }
}
    

