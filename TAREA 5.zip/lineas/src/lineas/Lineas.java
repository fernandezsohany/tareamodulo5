/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lineas;

/**
 *
 * @author Keren Serrano
 */

public class Lineas extends Forma {

    private double longitud;

    public Lineas (double longitud) {
        this.longitud = longitud;
    }

   
    public double calcularArea() {
        return 0; // Una línea no tiene área
    }

  
    public double calcularPerimetro() {
        return longitud; // Perímetro de una línea es su longitud
    }

   
    public void dibujar() {
        System.out.println("Dibujando Línea");
    }
}
    
