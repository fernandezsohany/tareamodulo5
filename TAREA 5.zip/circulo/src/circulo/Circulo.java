/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circulo;

/**
 *
 * @author Keren Serrano
 */


   public class Circulo extends forma {

    private final double radio;

    public Circulo(double radio) {
        this.radio = radio;
    }

   
    public double calcularArea() {
        return Math.PI * radio * radio;
    }

  
    public double calcularPerimetro() {
        return 2 * Math.PI * radio;
    }

    public void dibujar() {
        System.out.println("Dibujando Círculo");
    }
}

