/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package forma;

/**
 *
 * @author Keren Serrano
 */
public class Forma {
public abstract class forma {

    // Método abstracto para calcular el área (debe ser implementado por las subclases)
    public abstract double calcularArea();

    // Método abstracto para calcular el perímetro (debe ser implementado por las subclases)
    public abstract double calcularPerimetro();

    // Método común para dibujar la forma (será implementado en cada subclase)
    public void dibujar() {
        System.out.println("Dibujando " + getClass().getSimpleName());
    }
}
}

